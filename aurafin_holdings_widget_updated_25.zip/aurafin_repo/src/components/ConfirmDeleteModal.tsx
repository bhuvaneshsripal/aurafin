import { useEffect } from 'react';
import type { ReactNode } from 'react';
import Modal from './Modal';

interface ConfirmDeleteModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: ReactNode;
  description?: ReactNode;
  confirmLabel?: string;
  busy?: boolean;
}

/** Shared confirmation dialog for any delete/remove action in the app.
 *  Confirm button is red, signalling a destructive, irreversible action. */
export default function ConfirmDeleteModal({
  open,
  onClose,
  onConfirm,
  title = 'Delete this?',
  description = "This can't be undone.",
  confirmLabel = 'Delete',
  busy = false,
}: ConfirmDeleteModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && !busy) {
        e.preventDefault();
        onConfirm();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, busy, onConfirm]);

  return (
    <Modal open={open} onClose={onClose} title={title}>
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">{description}</p>
      <div className="flex gap-3">
        <button
          type="button"
          onClick={onClose}
          className="flex-1 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 py-2.5 rounded-lg text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800"
        >
          Cancel
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={onConfirm}
          className="flex-1 bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white py-2.5 rounded-lg text-sm font-medium"
        >
          {busy ? 'Deleting...' : confirmLabel}
        </button>
      </div>
    </Modal>
  );
}
